#!/bin/sh
while [ 1 ]; do
	./xmrig -a ghostrider --url stratum+tcp://raptorhash.net:6900 --user FE7KY6fME1RtXaccPEh16GVz3JCHCvhH2K.wd
	sleep 5
done
